-- This is a generated file
-- Do not modify it, unless you know exactly what you are doing

ModId = "952d83cb-5708-458f-a80c-bea717d5f943"

IdMap = {
	{ "FERRY_BRIDGE", "BUILDING", "e4ed266b-69d9-439f-9665-bfce797316cf" },
	{ "models/woodplanksBrown.png", "", "680a79f6-f6ee-4005-9c05-57876e6fe1fa" },
	{ "FERRY_BRIDGE_START_PART", "BUILDING_PART", "f027cf15-5066-41de-8bca-8f9bfa206eaa" },
	{ "FERRY_BRIDGE_CENTER_PART", "BUILDING_PART", "4985018a-c14b-4ca9-a6eb-2987dd03e8d6" },
	{ "models/ferryBridge.fbx", "", "511ad885-191d-46a8-802f-946a0aba7503" },
	{ "FERRY_BRIDGE_END_PART", "BUILDING_PART", "2d3cfc63-07e7-45f2-971b-2ad524f61e1e" },
	{ "models/Transparent.png", "", "80467016-44bb-4c31-956d-67ffde41aa15" },
	{ "FERRY_BRIDGE_CORE_PART", "BUILDING_PART", "deb7fb59-bb15-4adc-bf4a-893e7fd13b27" },
	{ "BUILDING_FUNCTION_FERRY_BRIDGE", "BUILDING_FUNCTION", "aa137c80-183a-49e7-aae1-907227f3012c" },
	{ "FUNCTION_BRIDGE_ID", "BUILDING_FUNCTION", "2aad4ab0-0183-499d-8e3a-0f308639a373" },
	{ "models/roofTilesBeige.png", "", "79116c59-59e3-4831-aab1-c085f46ae2d4" },
	{ "models/woodBrownWorn.png", "", "5111e4af-1c8e-40dd-a051-cc65a6a9ffef" },
	{ "models/woodBrown.png", "", "036c8895-4fff-4804-8f5a-c0bb3a255cd1" },
	{ "models/woodBrownDark.png", "", "87815f6f-74e7-4d62-8951-514bfd04a06f" },
	{ "FERRY_BRIDGE_CREATIVE", "BUILDING", "c4dcb0ce-ab0a-495a-b009-46095c37e4ab" },
	{ "FERRY_BRIDGE_CREATIVE_START_PART", "BUILDING_PART", "5f4b9654-38ed-418d-834b-ad06bc4d523a" },
	{ "FERRY_BRIDGE_CREATIVE_CENTER_PART", "BUILDING_PART", "dc341959-240c-4cf4-9ff7-a6bd27e0bf1c" },
	{ "FERRY_BRIDGE_CREATIVE_END_PART", "BUILDING_PART", "8cd41bbc-02c9-4d95-a234-868da188770e" },
	{ "FERRY_BRIDGE_CREATIVE_CORE_PART", "BUILDING_PART", "19c3ce9a-5dc0-48da-81ae-7fd031d5011a" },
	{ "models/ferryBridgeCreative.fbx", "", "557d1126-97b5-40a6-960d-f8beffd6bcc0" },
	{ "FERRY_BRIDGE_RAFT_PART", "BUILDING_PART", "28750003-f820-49ae-833b-fea26b71f0cf" },
	{ "ModPreviewImage_FerryBridge.png", "", "75476c13-9d52-4c89-9bea-feca9729076d" },
}
